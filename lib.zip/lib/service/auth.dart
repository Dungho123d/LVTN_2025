import 'package:flutter/foundation.dart';
import 'package:pocketbase/pocketbase.dart';
import 'package:study_application/service/pocketbase.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/user.dart';

class AuthService {
  /// Callback mỗi khi trạng thái đăng nhập thay đổi (user đăng nhập/đăng xuất)
  final void Function(User? user)? onAuthChange;

  AuthService({this.onAuthChange}) {
    if (onAuthChange != null) {
      // Khi có thay đổi ở authStore -> chuyển RecordModel thành User và bắn callback
      getPocketbaseInstance().then((pb) {
        pb.authStore.onChange.listen((event) {
          final record = event.record; // RecordModel? (null nếu đã logout)
          final user = record == null ? null : User.fromJson(record.toJson());
          onAuthChange!(user);
        });
      });
    }
  }

  /// Đăng ký tài khoản, sau đó tự động đăng nhập và trả về User
  Future<User> signup(String email, String password) async {
    final pb = await getPocketbaseInstance();

    try {
      // Tạo user mới trong collection 'users'
      await pb.collection('users').create(body: {
        'email': email,
        'password': password,
        'passwordConfirm': password,
      });

      // Đăng nhập luôn để lấy auth + record
      final auth =
          await pb.collection('users').authWithPassword(email, password);
      return User.fromJson(auth.record!.toJson());
    } catch (error) {
      if (error is ClientException) {
        // message chi tiết từ PocketBase
        throw Exception(error.response['message']);
      }
      throw Exception('Signup failed');
    }
  }

  /// Đăng nhập bằng email & password
  Future<User> login(String email, String password) async {
    final pb = await getPocketbaseInstance();

    try {
      final auth =
          await pb.collection('users').authWithPassword(email, password);
      return User.fromJson(auth.record!.toJson());
    } catch (error) {
      if (error is ClientException) {
        throw Exception(error.response['message']);
      }
      throw Exception('Login failed');
    }
  }

  /// Google OAuth2 - All-in-one flow theo docs PocketBase
  Future<User> loginWithGoogle() async {
    final pb = await getPocketbaseInstance();

    try {
      final authData = await pb.collection('users').authWithOAuth2(
        'google',
        // urlCallback: mở trang đăng nhập của provider
        (Uri authUrl) async {
          // Log ra để đối chiếu
          debugPrint('AUTH URL: $authUrl');
          debugPrint('REDIRECT = ${authUrl.queryParameters['redirect_uri']}');
          // Có thể thay bằng flutter_custom_tabs nếu muốn transition mượt hơn
          final ok =
              await launchUrl(authUrl, mode: LaunchMode.externalApplication);
          if (!ok) {
            throw Exception('Could not launch OAuth URL');
          }
        },
        // scopes tùy chọn (mặc định đủ dùng)
        // scopes: const ['email', 'profile'],
        // createData: {'name': 'New user'},  // nếu cần set field khi tạo lần đầu
      );

      // SDK đã cập nhật authStore; authData.record là user hiện tại
      return User.fromJson(authData.record!.toJson());
    } on ClientException catch (e) {
      // Lỗi có message từ PB
      throw Exception(e.response['message'] ?? 'OAuth2 failed');
    } catch (e) {
      throw Exception('Google sign-in failed: $e');
    }
  }

  Future<void> logout() async {
    final pb = await getPocketbaseInstance();
    pb.authStore.clear();
  }

  Future<User?> currentUser() async {
    final pb = await getPocketbaseInstance();
    final rec = pb.authStore.record;
    return rec == null ? null : User.fromJson(rec.toJson());
  }
}
