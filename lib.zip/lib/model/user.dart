class User {
  final String id;
  final String name;
  final int age;
  final String university;
  final String degree;
  final String subject;
  final String year;
  final String avatarUrl;

  const User({
    required this.id,
    required this.name,
    required this.age,
    required this.university,
    required this.degree,
    required this.subject,
    required this.year,
    required this.avatarUrl,
  });
}
