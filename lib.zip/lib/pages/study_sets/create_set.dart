import 'package:flutter/material.dart';

/// Kết quả form trả về sau khi bấm Create
class StudySetForm {
  final String name;
  final String description;
  final bool isPrivate;

  const StudySetForm({
    required this.name,
    required this.description,
    required this.isPrivate,
  });
}

/// Mở dialog tạo Study Set.
/// Trả về `StudySetForm` nếu bấm Create, hoặc `null` nếu Cancel.
Future<StudySetForm?> openCreateStudySetDialog(
  BuildContext context, {
  String? initialName,
  String? initialDescription,
  bool initialPrivate = false,
}) {
  final nameCtrl = TextEditingController(text: initialName ?? "");
  final descCtrl = TextEditingController(text: initialDescription ?? "");
  bool isPrivate = initialPrivate;

  final formKey = GlobalKey<FormState>();

  return showDialog<StudySetForm>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) {
      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        titlePadding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
        contentPadding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
        actionsPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        title: Row(
          children: const [
            Icon(Icons.folder_open_rounded, color: Color(0xFF00A6B2)),
            SizedBox(width: 8),
            Text('Create Study Set',
                style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        content: StatefulBuilder(
          builder: (_, setState) {
            return SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Name
                    TextFormField(
                      controller: nameCtrl,
                      autofocus: true,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(
                        labelText: 'Name',
                        hintText: 'e.g. Cell Biology',
                        border: OutlineInputBorder(),
                      ),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) {
                          return 'Please enter a name';
                        }
                        if (v.trim().length < 3) {
                          return 'Name must be at least 3 characters';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),

                    // Description
                    TextFormField(
                      controller: descCtrl,
                      minLines: 3,
                      maxLines: 5,
                      decoration: const InputDecoration(
                        labelText: 'Description (optional)',
                        hintText: 'Briefly describe your study set…',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Private toggle
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF6F7FB),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFE7E9F0)),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            isPrivate ? Icons.lock_outline : Icons.public,
                            color: Colors.black87,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              isPrivate
                                  ? 'Private (only you can see)'
                                  : 'Public (everyone can see)',
                              style:
                                  const TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ),
                          Switch(
                            value: isPrivate,
                            activeColor: const Color(0xFF00A6B2),
                            onChanged: (v) => setState(() => isPrivate = v),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (!formKey.currentState!.validate()) return;
              Navigator.pop(
                ctx,
                StudySetForm(
                  name: nameCtrl.text.trim(),
                  description: descCtrl.text.trim(),
                  isPrivate: isPrivate,
                ),
              );
            },
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF00A6B2),
            ),
            child: const Text('Create'),
          ),
        ],
      );
    },
  );
}
