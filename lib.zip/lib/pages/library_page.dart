import 'package:flutter/material.dart';
import 'package:study_application/manager/studysets_manager.dart';
import 'package:study_application/model/study_set.dart'; // Thay thế LibraryItem bằng StudySet
import 'package:study_application/pages/study_sets/detail/materials.dart';
import 'package:study_application/utils/color.dart';

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key, this.onItemTap});

  final ValueChanged<StudySet>?
      onItemTap; // Cập nhật kiểu từ LibraryItem sang StudySet

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FB),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFFF6F7FB),
        surfaceTintColor: Colors.transparent,
        centerTitle: true,
        automaticallyImplyLeading: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: CircleAvatar(
            radius: 16,
            backgroundColor: const Color(0xFF00A6B2).withOpacity(.12),
            child: const Icon(Icons.psychology_alt, color: Color(0xFF00A6B2)),
          ),
        ),
        title: const Text(
          'Library',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w800,
            fontSize: 20,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 6),
            child: Icon(Icons.more_vert, color: Colors.black87),
          )
        ],
      ),
      body: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        itemCount: StudySetManager.demoSets.length, // Sử dụng StudySetManager
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, i) {
          final item = StudySetManager.demoSets[i];
          return LibraryCard(
            item: item,
            onTap: () => _openDetail(context, item),
          );
        },
      ),
    );
  }

  void _openDetail(BuildContext context, StudySet item) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => StudySetDetailPage(title: item.title),
      ),
    );
  }
}

/// ===================== CARD =====================
class LibraryCard extends StatelessWidget {
  final StudySet item; // Thay LibraryItem bằng StudySet
  final VoidCallback? onTap;
  final VoidCallback? onMore;

  const LibraryCard({
    super.key,
    required this.item,
    this.onTap,
    this.onMore,
  });

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.randomAccent();

    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Ink(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE9ECF3)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 14,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // dải màu trái
                Container(
                  width: 4,
                  decoration: BoxDecoration(
                    color: accent,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
                const SizedBox(width: 12),

                // nội dung giữa
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // tiêu đề + progress tròn bên phải
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(
                              item.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 16,
                              ),
                            ),
                          ),
                          _ProgressCircle(
                            value: item.progress,
                            color: accent,
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),

                      // meta line
                      Text(
                        '${item.flashcards} flashcards  ·  ${item.explanations} explanations  ', // Thêm exercises
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),

                      const SizedBox(height: 10),
                      const Divider(height: 1, color: Color(0xFFEFF1F5)),
                      const SizedBox(height: 8),

                      // chips + actions
                      Row(
                        children: [
                          if (item.byYou)
                            _softChip(
                              label: 'By you',
                              icon: Icons.person_outline,
                            ),
                          if (item.isCommunity) ...[
                            const SizedBox(width: 8),
                            _softChip(
                              label: 'Community',
                              icon: Icons.groups_2_outlined,
                            ),
                          ],
                          const Spacer(),
                          Icon(Icons.lock_outline,
                              size: 18, color: Colors.grey.shade700),
                          const SizedBox(width: 12),
                          const Icon(Icons.public,
                              size: 18, color: Colors.black54),
                          const SizedBox(width: 12),
                          GestureDetector(
                            onTap: onMore,
                            child: const Icon(Icons.more_vert,
                                size: 18, color: Colors.black54),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _softChip({required String label, required IconData icon}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF6F7FB),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFE7E9F0)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 14, color: Colors.grey.shade700),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey.shade700,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _ProgressCircle extends StatelessWidget {
  final double value; // 0..1
  final Color color;
  const _ProgressCircle({required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    final percent = (value * 100).round();
    return SizedBox(
      height: 38,
      width: 38,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CircularProgressIndicator(
            value: value.clamp(0, 1),
            strokeWidth: 4,
            backgroundColor: color.withOpacity(0.15),
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
          Text(
            '$percent%',
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}
