import 'package:study_application/models/user.dart';

class UserManager {
  static final demoUser = User(
    id: 'u1',
    name: 'Andrew',
    email: 'andrew@example.com',
    // age: 20,
    // university: 'Harvard University',
    // degree: 'Bachelor',
    // subject: 'Biology',
    // year: 'Junior',
    // avatarUrl: 'assets/images/avatar.png',
  );
}
